# boldlook by yogi_nation — Website Design

## 1. Design Overview

**Project Name:** boldlook by yogi_nation  
**Type:** Streetwear brand launch site (lookbook + drops + manifesto)  
**Visual Style:** gritty, high-contrast, editorial, neon-accented, kinetic  
**Primary Headline/Tagline:** **"Street Is The New Luxury."**

---

## 2. Visual Identity

### Color System

Background Primary:   `#0B0B0D` (near-black, used for 80%+ of sections)  
Background Secondary: `#6B2B2B` (deep crimson red, used for 1–2 sections only)  
Accent:               `#B6FF2E` (neon lime for CTAs, highlights, rules)  
Text Primary:         `#F4F4F5` (off-white)  
Text Secondary:       `#A1A1AA` (cool gray for captions/meta)

**Color unification rules**
- Keep the page "night mode": **Background Primary** dominates.
- **Background Secondary** is reserved for the Manifesto section only.
- **Accent** is the *only* highlight color (no additional accent colors).

### Typography

**Headings (Display / H1–H2):**  
- Font: `Archivo Black` (fallback: `Impact`, `Arial Black`)  
- Weight: 400 (Black)  
- Style: ALL CAPS, tight leading  
- Letter-spacing: `-0.02em` to `-0.04em`  
- Sizes:
  - Hero H1: `clamp(56px, 7vw, 112px)`
  - Section H2: `clamp(44px, 5.5vw, 84px)`

**Body:**  
- Font: `Inter`  
- Weight: 400–500  
- Size: `16–18px` desktop, `15–16px` mobile  
- Line-height: 1.55–1.7  
- Color: Text Secondary

**Accent / Micro-labels (Meta, captions, small UI):**  
- Font: `Space Mono`  
- Weight: 400  
- Size: `12–13px`  
- Letter-spacing: `0.08em`  
- Transform: uppercase

### Visual Elements

**Texture / Grain**
- Global static grain overlay: PNG noise tile at `8–10%` opacity, `mix-blend-mode: overlay`.
- Keep it static (no animated noise).

**Rules / Lines**
- 1px lines in `rgba(181,255,46,0.65)` (Accent at 65% opacity).
- Used under headings and as section dividers.

**Corners / Radius**
- Buttons: `border-radius: 999px` (pill)
- Cards: `border-radius: 10px`
- Images: mostly sharp corners (`0–6px`); occasional `10px` for product cards.

**Shadows**
- Minimal, static only:
  - `0 18px 50px rgba(0,0,0,0.45)` for product cards
  - `0 10px 30px rgba(0,0,0,0.35)` for nav

**Iconography**
- Simple geometric icons (hamburger, close, arrow) as inline SVG.
- Stroke width: 2px, rounded caps.

### Visual Consistency (Critical)

1. **Background simplification:** Only near-black + one crimson section.  
2. **Image treatment (single method):** **High-contrast monochrome + subtle cool tint**  
   - Reduce saturation to near-zero, lift blacks slightly, add subtle blue/cool curve, keep strong contrast.  
3. **Accent discipline:** Neon lime only for CTAs, active states, key lines, and small highlights.  
4. **Mood preserved:** Night editorial, graffiti-era energy, modern minimal UI.

---

## 3. Section Structure

**Total Sections:** 7

**Section Flow**
1. **Section 1:** Night hero portrait + giant logo — **Hero** — **pin: true**  
2. **Section 2:** Split editorial (left portrait / right stacked images) — **Lookbook teaser** — **pin: true**  
3. **Section 3:** Full-bleed street scene + oversized heading — **Brand statement** — **pin: true**  
4. **Section 4:** Two-up portraits + "COLLECTION 01" — **Drop highlight** — **pin: true**  
5. **Section 5:** Product grid (6 items) — **Shop** — **pin: false**  
6. **Section 6:** Crimson manifesto + newsletter — **Community** — **pin: false**  
7. **Section 7:** Contact + footer — **Closing** — **pin: false**

**Persistent Elements (all sections)**
- **Top-left:** "boldlook" wordmark (text logo)
- **Top-right:** pill button "MENU" (opens overlay) + optional cart icon
- No progress dots, no page numbers.

**Navigation Pattern**
- Scroll drives the story.
- Menu overlay provides anchor jumps to: Lookbook, Collection, Shop, Manifesto, Contact.
- Optional keyboard: ↑/↓ or PageUp/PageDown to nudge between pinned scenes.

---

## 4. Tech Stack

- Build Tool: **Vite**
- Framework: **React**
- Animation: **GSAP + ScrollTrigger** (primary)
- Optional:
  - **Lenis** for smooth scrolling (only if it doesn't fight ScrollTrigger; test thoroughly)
  - **SplitType** for heading character/word splitting

---

## 5. Section-by-Section Design

### Section 1: "Night Logo" (Hero)

**pin:** `true`

**Section Purpose:** Immediate brand imprint. Night editorial tone. Establish the "giant type + portrait" language.

**Composition (full-viewport, no max-width)**
- **Background:** full-bleed hero portrait image (night, city lights, subject centered).
- **Giant outline logo:** centered, spanning most of viewport width.
  - Position: `left: 50%`, `top: 52%`, `transform: translate(-50%, -50%)`
  - Z: above image, below nav
- **Bottom-left micro label:** "BOLDLOOK BY YOGI_NATION"
  - Position: `left: 4vw`, `bottom: 4vh`
- **Bottom-right CTA pill:** "ENTER THE DROP"
  - Position: `right: 4vw`, `bottom: 4vh`
- **Top-right utility:** "MENU" pill button
  - Position: `right: 4vw`, `top: 4vh`
- **Top-left wordmark:** "boldlook"
  - Position: `left: 4vw`, `top: 4vh`

**Content**
- Micro label (bottom-left): "BOLDLOOK BY YOGI_NATION" — position: bottom-left
- CTA (bottom-right): "ENTER THE DROP" — position: bottom-right
- Optional tiny meta under CTA (Space Mono): "NEW SEASON LIVE" — position: bottom-right, above CTA

**Visual Elements**
- Grain overlay across entire viewport.
- Outline text uses stroke only: ` -webkit-text-stroke: 2px rgba(255,255,255,0.9)` with fill transparent.
- CTA pill: Background `Accent`, text `Background Primary` (black), very bold.

**Auto-play Entrance Animation (page load, not scroll)**
- Background image: fade in `opacity 0 → 1`, slight scale `1.06 → 1.00` (1.1s, `power2.out`)
- Giant outline logo: `scale 0.92 → 1`, `opacity 0 → 1` (0.9s, `power3.out`)
- Wordmark + MENU: slide down `y: -20px → 0`, `opacity 0 → 1` (0.6s, stagger 0.08s)
- Bottom-left micro label: `x: -30px → 0`, `opacity 0 → 1` (0.6s)
- CTA: `y: 20px → 0`, `opacity 0 → 1` (0.6s)

**Scroll-Driven Element Animation (scroll controls exit only; settle state must match load end)**
- **ScrollTrigger:** `start: "top top"`, `end: "+=130%"`, `pin: true`, `scrub: 0.5`
- **Settle window:** 30%–70% (static)
- **settleRatio (snap target):** `0.50`

**Three-phase mapping**
- **ENTRANCE (0%–30%)**: *Hold* (no re-entrance; elements already visible from load).  
  - Optional micro-parallax only: background `y: 0 → -2vh` (very subtle).
- **SETTLE (30%–70%)**: Hold all.
- **EXIT (70%–100%)**:
  - Giant outline logo: `opacity 1 → 0.25` by 92%, then `0` at 98%
  - Hero portrait: `x: 0 → -18vw`, `scale: 1 → 1.08`, `opacity: 1 → 0.35` (to 95%), then `0` at 99%
  - CTA + micro label: `y: 0 → 12vh`, `opacity: 1 → 0` by 98%
  - Wordmark + MENU: `y: 0 → -10vh`, `opacity: 1 → 0` by 98%

**Section Transition Behavior**
- Next section enters **on top** starting ~80% of this section's exit (higher z-index).
- Avoid vertical "push"; keep it cinematic (scene replacement).

**Implementation Notes**
- Add `onLeaveBack` to force hero elements back to visible state at top.
- Ensure ScrollTrigger timeline does not define hidden start states for hero text.

---

### Section 2: "Split Editorial"

**pin:** `true`

**Section Purpose:** Establish the "lookbook" language: split layout, stacked images, bold typographic label.

**Composition**
- **Left image (portrait):** `left: 0`, `top: 0`, `width: 50vw`, `height: 100vh`
- **Right top image:** `left: 50vw`, `top: 0`, `width: 50vw`, `height: 50vh`
- **Right bottom image:** `left: 50vw`, `top: 50vh`, `width: 50vw`, `height: 50vh`
- **Vertical divider line:** `left: 50vw`, `top: 10vh`, `height: 80vh`, `width: 1px`, color Accent at 40%
- **Bottom-left heading:** "LOOKBOOK"
  - Position: `left: 4vw`, `bottom: 6vh`
- **Bottom-left paragraph:** short descriptor
  - Position: `left: 4vw`, `bottom: 4vh`, max-width `34vw`

**Content**
- Heading: "LOOKBOOK" — position: bottom-left
- Body: "Night portraits, raw textures, and pieces built for the street." — position: bottom-left under heading
- CTA (small, under paragraph): "VIEW LOOKBOOK" — position: bottom-left

**Visual Elements**
- Images: monochrome treatment, consistent contrast.
- A thin accent rule under the heading (2px height, 12ch width).

**Scroll-Driven Element Animation (pinned, three-phase)**
- **ScrollTrigger:** `start: "top top"`, `end: "+=130%"`, `pin: true`, `scrub: 0.5`
- **Settle window:** 30%–70%
- **settleRatio:** `0.50`

**Three-phase mapping**
- **ENTRANCE (0%–30%)**
  - Left portrait: start `x: -60vw`, `opacity: 0` → end `x: 0`, `opacity: 1` (0–22%)
  - Right top image: start `x: +60vw`, `opacity: 0` → end `x: 0`, `opacity: 1` (0–22%)
  - Right bottom image: start `x: +60vw`, `opacity: 0` → end `x: 0`, `opacity: 1` (6–28%)
  - Divider line: start `scaleY: 0` (origin top) → end `scaleY: 1` (10–30%)
  - "LOOKBOOK": start `y: +40vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (12–30%)
  - Paragraph: start `y: +18vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (16–30%)
  - CTA: start `y: +10vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (20–30%)
- **SETTLE (30%–70%)**
  - All elements hold.
- **EXIT (70%–100%)**
  - Left portrait: `x: 0 → -35vw`, `opacity: 1 → 0.3` (to 95%), then `0` at 99%
  - Right images: `x: 0 → +35vw`, `opacity: 1 → 0.3` (to 95%), then `0` at 99%
  - Text block: `y: 0 → +18vh`, `opacity: 1 → 0` by 98%
  - Divider: `scaleY: 1 → 0` (origin bottom) (85–100%)

**Section Transition Behavior**
- Section 3's heading begins entering at ~82% while Section 2 images are still faintly visible (overlay replacement).

---

### Section 3: "Street Statement"

**pin:** `true`

**Section Purpose:** A bold brand statement. Full-bleed street scene + oversized heading + neon rule.

**Composition**
- **Background:** full-bleed street scene image (subject center-left, urban background).
- **Top-right micro label:** "BOLDLOOK BY YOGI_NATION"
  - Position: `right: 4vw`, `top: 6vh`
- **Bottom-left giant heading:** "STREET IS THE NEW LUXURY"
  - Position: `left: 4vw`, `bottom: 10vh`, width `92vw`
- **Neon rule:** thin line under heading, aligned left
  - Position: `left: 4vw`, `bottom: 8vh`, width `60vw`

**Content**
- Micro label: "BOLDLOOK BY YOGI_NATION" — position: top-right
- Heading: "STREET IS THE NEW LUXURY" — position: bottom-left
- Small CTA (under rule): "READ THE MANIFESTO" — position: bottom-left

**Scroll-Driven Element Animation (pinned, three-phase)**
- **ScrollTrigger:** `start: "top top"`, `end: "+=130%"`, `pin: true`, `scrub: 0.5`
- **Settle window:** 30%–70%
- **settleRatio:** `0.50`

**Three-phase mapping**
- **ENTRANCE (0%–30%)**
  - Background image: start `scale: 1.14`, `opacity: 0` → end `scale: 1`, `opacity: 1` (0–25%)
  - Micro label: start `x: +20vw`, `opacity: 0` → end `x: 0`, `opacity: 1` (8–22%)
  - Heading (word-stagger): start `y: +60vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (10–30%)  
    - Split by words; stagger 0.03 timeline-wise (transform-only).
  - Neon rule: start `scaleX: 0` (origin left) → end `scaleX: 1` (18–30%)
  - CTA: start `y: +10vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (20–30%)
- **SETTLE (30%–70%)**
  - Hold.
- **EXIT (70%–100%)**
  - Heading: `y: 0 → -30vh`, `opacity: 1 → 0.25` (to 95%), then `0` at 99%
  - Background: `x: 0 → +18vw`, `opacity: 1 → 0.35` (to 95%), then `0` at 99%
  - Micro label + CTA: `opacity: 1 → 0` by 98%
  - Rule: `scaleX: 1 → 0` (origin right) (85–100%)

---

### Section 4: "Collection 01"

**pin:** `true`

**Section Purpose:** The drop moment. Two portraits + big collection title + product CTA.

**Composition**
- **Left image:** `left: 0`, `top: 0`, `width: 50vw`, `height: 100vh`
- **Right image:** `left: 50vw`, `top: 0`, `width: 50vw`, `height: 100vh`
- **Top-left micro label:** "BOLDLOOK BY YOGI_NATION"
  - Position: `left: 4vw`, `top: 6vh`
- **Center heading (spans both halves):** "COLLECTION 01"
  - Position: `left: 50%`, `top: 52%`, `transform: translate(-50%, -50%)`
  - Add subtle dark behind text for readability: `text-shadow: 0 10px 30px rgba(0,0,0,0.6)`
- **Bottom-center CTA pill:** "SHOP THE DROP"
  - Position: `left: 50%`, `bottom: 6vh`, `transform: translateX(-50%)`

**Content**
- Micro label: "BOLDLOOK BY YOGI_NATION" — position: top-left
- Heading: "COLLECTION 01" — position: center
- CTA: "SHOP THE DROP" — position: bottom-center
- Tiny meta under CTA (Space Mono): "LIMITED UNITS" — position: bottom-center, above CTA

**Scroll-Driven Element Animation (pinned, three-phase)**
- **ScrollTrigger:** `start: "top top"`, `end: "+=130%"`, `pin: true`, `scrub: 0.5`
- **Settle window:** 30%–70%
- **settleRatio:** `0.50`

**Three-phase mapping**
- **ENTRANCE (0%–30%)**
  - Left image: start `x: -60vw`, `opacity: 0` → end `x: 0`, `opacity: 1` (0–22%)
  - Right image: start `x: +60vw`, `opacity: 0` → end `x: 0`, `opacity: 1` (0–22%)
  - Micro label: start `y: -10vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (10–22%)
  - "COLLECTION 01": start `scale: 0.72`, `y: +10vh`, `opacity: 0` → end `scale: 1`, `y: 0`, `opacity: 1` (12–30%)
  - CTA: start `y: +18vh`, `opacity: 0` → end `y: 0`, `opacity: 1` (18–30%)
  - Meta: start `opacity: 0` → `1` (22–30%)
- **SETTLE (30%–70%)**
  - Hold.
- **EXIT (70%–100%)**
  - Heading: `scale: 1 → 1.25`, `opacity: 1 → 0.2` (to 95%), then `0` at 99%
  - Images: `opacity: 1 → 0.25` (to 95%), then `0` at 99%
  - CTA + meta: `y: 0 → +12vh`, `opacity: 1 → 0` by 98%

**Section Transition Behavior**
- Fade into the product grid (Section 5) without a "page scroll" feel: grid begins appearing at ~85% while pinned images are still faint.

---

### Section 5: "Shop Grid"

**pin:** `false`

**Section Purpose:** Content-heavy shopping area. Clean editorial grid, readable, easy to interact.

**Composition (flowing)**
- Background: `#0B0B0D`
- Top padding: `10vh`
- Heading row:
  - Left: "NEW DROP" (H2)
  - Right: filter chips (pills): "ALL", "HOODIES", "TEES", "OUTERWEAR"
- Grid: 3 columns desktop, 2 tablet, 1 mobile
  - Gap: `clamp(14px, 2vw, 28px)`
  - Card: image + product name + price + "Add" button

**Content**
- Heading: "NEW DROP"
- Body: "Built for movement. Designed to stand out."
- 6 product cards (example):
  1. "Night Hoodie" — ₹4,999
  2. "Concrete Tee" — ₹2,499
  3. "Metro Bomber" — ₹6,499
  4. "Signal Cargo" — ₹3,999
  5. "Tag Cap" — ₹1,799
  6. "Stencil Socks (2-pack)" — ₹999
- CTA (below grid): "VIEW ALL PRODUCTS" (accent outline pill)

**Scroll-Driven Element Animation (flowing)**
- Heading + filters:
  - Start: `y: +6vh`, `opacity: 0`
  - End: `y: 0`, `opacity: 1`
  - Trigger: when section top reaches `80%` viewport
  - Scrub: `scrub: 0.3` over a small range (e.g., `start: "top 80%"`, `end: "top 55%"`)
- Product cards (each card):
  - Start: `y: +10vh`, `rotate: -1deg`, `opacity: 0`
  - End: `y: 0`, `rotate: 0deg`, `opacity: 1`
  - Stagger: 0.08 per card
  - Trigger: card enters `85%` viewport; `end: "top 60%"`, `scrub: 0.3`
- Hover (desktop):
  - Card image: `scale(1) → scale(1.03)` (transform-only)
  - "Add" button: `translateY(6px) → 0` and `opacity 0 → 1`

**Implementation Notes**
- Keep this section **unpinned** so users can read and click freely.
- Ensure filters are accessible (keyboard + screen reader).

---

### Section 6: "Manifesto" (Community)

**pin:** `false`

**Section Purpose:** A bold manifesto moment + newsletter signup. The only place the crimson background appears.

**Composition**
- Background: `#6B2B2B` with grain overlay
- Top: big manifesto heading (left aligned)
- Bottom-right: newsletter card (dark) with email input + button

**Content**
- Heading: "THIS IS NOT BASIC."
- Subheadline: "We design for the ones who move different. Join the list—first access to drops, no spam."
- Newsletter:
  - Label: "JOIN THE LIST"
  - Placeholder: "Email address"
  - Button: "SUBSCRIBE"
  - Microcopy: "Unsubscribe anytime. We don't share your data."

**Scroll-Driven Element Animation (flowing)**
- Heading:
  - Start: `x: -8vw`, `opacity: 0`
  - End: `x: 0`, `opacity: 1`
  - Range: `top 80%` → `top 55%`, `scrub: 0.3`
- Newsletter card:
  - Start: `x: +8vw`, `opacity: 0`
  - End: `x: 0`, `opacity: 1`
  - Range: `top 75%` → `top 50%`, `scrub: 0.3`
- Button hover (transform-only): `scale(1) → scale(1.02)`

---

### Section 7: "Contact / Footer"

**pin:** `false`

**Section Purpose:** Close with contact, socials, and a clean footer.

**Composition**
- Background: `#0B0B0D`
- Two-column layout (desktop):
  - Left: contact info
  - Right: form (Name, Email, Message)
- Footer row: copyright + social links

**Content**
- H2: "COLLABORATE"
- Body: "Stockists, press, and creative collabs—reach out."
- Contact details:
  - "hello@boldlook.co"
  - "Delhi + Mumbai"
- Form CTA: "SEND MESSAGE"
- Footer: "© 2026 boldlook by yogi_nation. All rights reserved."

**Scroll-Driven Element Animation (flowing)**
- Left column: `y: +6vh`, `opacity 0 → 1` (scrub 0.3)
- Right form: `y: +8vh`, `opacity 0 → 1` (scrub 0.3)
- Footer: fade in near bottom

---

## 6. Animation System

### Scroll-Driven Animation Architecture
- Use GSAP timelines per section.
- **Pinned sections:** `pin: true`, `scrub: 0.5`, `end: "+=130%"`
- **Flowing sections:** per-element ScrollTriggers with small scrub ranges.
- Use `fromTo()` everywhere for reversible scroll.
- Avoid blur/backdrop-filter; use only transform + opacity.

### Entry Direction Rules (applied consistently)
- Left-side elements enter from left (`x: -50vw`)
- Right-side elements enter from right (`x: +50vw`)
- Bottom text enters from bottom (`y: +40vh`)
- Center headings can scale in (`scale: 0.7 → 1`)

### Z-Index Stacking (critical)
- Assign increasing z-index by section order:
  - Section 1: 10
  - Section 2: 20
  - Section 3: 30
  - Section 4: 40
  - Section 5+: normal flow (no pin)
- This enables "next scene overlays current scene" transitions.

### Scroll Snap Configuration (Required)
- **Snap only to pinned sections**, and snap to their settle centers.
- **No delay**, fast slide-like snap.

**Global snap approach**
- After creating all ScrollTriggers, derive pinned ranges.
- For each pinned trigger, use its `settleRatio` (default 0.5) to compute the snap target.
- If scroll position is inside a pinned range (±2% buffer), snap to that target.
- If outside pinned ranges (flowing sections), keep scroll free (return value = current).

**Snap behavior**
- Duration: distance-aware, clamp `0.15–0.35s`
- Ease: `power2.out`

(Implement using the "derive targets from actual pinned ScrollTriggers" pattern; flowing sections remain unsnapped.)

### Reduced Motion
- Respect `prefers-reduced-motion`:
  - Disable pinning (or reduce to simple fades)
  - Remove large translations
  - Keep content readable and accessible

---

## 7. Asset Inventory

### Image Treatment (apply to ALL photos)
**High-contrast monochrome + subtle cool tint**  
- Saturation near zero  
- Strong contrast, deep blacks  
- Slight blue/cool curve in shadows  
- Add global grain overlay in UI (not baked into images)

### Images Required

**hero_portrait**
- Purpose: Section 1 background
- Position: Section 1, full-bleed
- Dimensions: 16:9 (safe crop for 9:16 on mobile)
- Color Treatment: monochrome + cool tint
- Prompt: "Night editorial street portrait, subject centered, city lights bokeh in background, high contrast black and white with subtle cool tint, gritty urban mood, sharp focus, cinematic lighting"

**lookbook_left_portrait**
- Purpose: Section 2 left panel
- Position: Section 2, left 50%
- Dimensions: 3:4
- Color Treatment: monochrome + cool tint
- Prompt: "Editorial street portrait, subject looking off-camera, high contrast monochrome with subtle cool tint, gritty texture, minimal background"

**lookbook_right_top**
- Purpose: Section 2 right top
- Position: Section 2, right top 50%
- Dimensions: 4:3
- Color Treatment: monochrome + cool tint
- Prompt: "Street fashion detail shot, subject adjusting jacket collar, high contrast monochrome with subtle cool tint, gritty urban feel"

**lookbook_right_bottom**
- Purpose: Section 2 right bottom
- Position: Section 2, right bottom 50%
- Dimensions: 4:3
- Color Treatment: monochrome + cool tint
- Prompt: "Street portrait with neon signage in background, high contrast monochrome with subtle cool tint, moody night atmosphere"

**street_scene_bg**
- Purpose: Section 3 background
- Position: Section 3, full-bleed
- Dimensions: 16:9
- Color Treatment: monochrome + cool tint
- Prompt: "Wide street scene at night, subject center-left, urban background with lights, high contrast monochrome with subtle cool tint, cinematic depth"

**collection_left**
- Purpose: Section 4 left panel
- Position: Section 4, left 50%
- Dimensions: 3:4
- Color Treatment: monochrome + cool tint
- Prompt: "Streetwear portrait, subject standing against wall, high contrast monochrome with subtle cool tint, bold stance, gritty texture"

**collection_right**
- Purpose: Section 4 right panel
- Position: Section 4, right 50%
- Dimensions: 3:4
- Color Treatment: monochrome + cool tint
- Prompt: "Streetwear portrait, subject looking at camera, high contrast monochrome with subtle cool tint, minimal background, strong contrast"

**product_hoodie**
- Purpose: Section 5 product card
- Position: Section 5 grid
- Dimensions: 1:1
- Color Treatment: monochrome + cool tint
- Prompt: "Product photo of an oversized black hoodie on a neutral background, high contrast monochrome with subtle cool tint, minimal, streetwear aesthetic"

**product_tee**
- Purpose: Section 5 product card
- Position: Section 5 grid
- Dimensions: 1:1
- Color Treatment: monochrome + cool tint
- Prompt: "Product photo of a black boxy t-shirt on a neutral background, high contrast monochrome with subtle cool tint, minimal, streetwear aesthetic"

**product_bomber**
- Purpose: Section 5 product card
- Position: Section 5 grid
- Dimensions: 1:1
- Color Treatment: monochrome + cool tint
- Prompt: "Product photo of a black bomber jacket on a neutral background, high contrast monochrome with subtle cool tint, minimal, streetwear aesthetic"

**product_cargo**
- Purpose: Section 5 product card
- Position: Section 5 grid
- Dimensions: 1:1
- Color Treatment: monochrome + cool tint
- Prompt: "Product photo of black cargo pants on a neutral background, high contrast monochrome with subtle cool tint, minimal, streetwear aesthetic"

**product_cap**
- Purpose: Section 5 product card
- Position: Section 5 grid
- Dimensions: 1:1
- Color Treatment: monochrome + cool tint
- Prompt: "Product photo of a black 5-panel cap on a neutral background, high contrast monochrome with subtle cool tint, minimal, streetwear aesthetic"

**product_socks**
- Purpose: Section 5 product card
- Position: Section 5 grid
- Dimensions: 1:1
- Color Treatment: monochrome + cool tint
- Prompt: "Product photo of black crew socks with minimal branding on a neutral background, high contrast monochrome with subtle cool tint, streetwear aesthetic"

### Procedural Graphics
- **grain_overlay.png**
  - Render: CSS background-image on a fixed overlay div
  - Motion: none (static)
  - Appears: all sections
- **accent_rules (CSS)**
  - Render: divs with background color Accent
  - Motion: scaleX/scaleY reveals in entrances
  - Appears: Sections 2–4

---

## 8. Layout & Spacing

**Section spacing**
- Pinned sections: always `100vw × 100vh`, no extra vertical padding.
- Flowing sections: compact padding `8vh 0` to `12vh 0`; avoid large dead zones.

**Responsive strategy**
- Desktop: exact compositions as specified.
- Tablet:
  - Reduce heading sizes slightly
  - Keep split layouts, but increase text safe margins
- Mobile:
  - Split layouts become stacked:
    - Section 2: left image becomes top 50%, right images bottom 50%
    - Section 4: left image top 50%, right image bottom 50%, heading stays centered
  - Reduce giant outline logo stroke width (1px)
  - Keep CTAs tappable (min 44px)

---

## 9. Complete Copy Document

**Persistent / Navigation**
- Logo: "boldlook"
- Menu button: "MENU"
- Menu items:
  - "LOOKBOOK"
  - "COLLECTION 01"
  - "SHOP"
  - "MANIFESTO"
  - "CONTACT"
- Close: "CLOSE"

**Section 1**
- "BOLDLOOK BY YOGI_NATION"
- "ENTER THE DROP"
- "NEW SEASON LIVE"

**Section 2**
- "LOOKBOOK"
- "Night portraits, raw textures, and pieces built for the street."
- "VIEW LOOKBOOK"

**Section 3**
- "BOLDLOOK BY YOGI_NATION"
- "STREET IS THE NEW LUXURY"
- "READ THE MANIFESTO"

**Section 4**
- "BOLDLOOK BY YOGI_NATION"
- "COLLECTION 01"
- "SHOP THE DROP"
- "LIMITED UNITS"

**Section 5**
- "NEW DROP"
- "Built for movement. Designed to stand out."
- Filters: "ALL", "HOODIES", "TEES", "OUTERWEAR"
- Products:
  - "Night Hoodie" — "₹4,999"
  - "Concrete Tee" — "₹2,499"
  - "Metro Bomber" — "₹6,499"
  - "Signal Cargo" — "₹3,999"
  - "Tag Cap" — "₹1,799"
  - "Stencil Socks (2-pack)" — "₹999"
- "VIEW ALL PRODUCTS"

**Section 6**
- "THIS IS NOT BASIC."
- "We design for the ones who move different. Join the list—first access to drops, no spam."
- "JOIN THE LIST"
- Button: "SUBSCRIBE"
- "Unsubscribe anytime. We don't share your data."

**Section 7**
- "COLLABORATE"
- "Stockists, press, and creative collabs—reach out."
- "hello@boldlook.co"
- "Delhi + Mumbai"
- Form labels: "Name", "Email", "Message"
- Button: "SEND MESSAGE"
- Footer: "© 2026 boldlook by yogi_nation. All rights reserved."

---

## Requirements Checklist

**Pinned sections**
- [x] 4 pinned sections (Sections 1–4)  
- [x] 3 flowing sections (Sections 5–7)  
- [x] Pinned sections include `end: "+=130%"`  
- [x] Three-phase structure defined for each pinned section  
- [x] Settle state readable, no awkward overlaps  
- [x] Snap targets derived from pinned ranges only; flowing sections free-scroll  
- [x] Fast snap (0.15–0.35s), no delay  
- [x] Z-index stacking specified (next over previous)  
- [x] Hero auto-play entrance animation defined (scroll handles exit only)  

**Animation system**
- [x] GSAP + ScrollTrigger used  
- [x] `fromTo()` used for reversible animations  
- [x] Transform-based only (no blur/backdrop-filter)  
- [x] Tight scroll distances (`+=130%`)  

**Visual consistency**
- [x] Unified palette (1 primary background, 1 secondary, 1 accent)  
- [x] Single image treatment (monochrome + cool tint)  
- [x] No additional accent colors  
- [x] Typography hierarchy defined (1 display font, 1 body, 1 mono)

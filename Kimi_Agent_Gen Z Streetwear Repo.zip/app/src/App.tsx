import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { X, ShoppingBag, ArrowRight } from 'lucide-react';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

// Product data
const products = [
  { id: 1, name: 'Night Hoodie', price: '₹4,999', image: '/product_hoodie.jpg' },
  { id: 2, name: 'Concrete Tee', price: '₹2,499', image: '/product_tee.jpg' },
  { id: 3, name: 'Metro Bomber', price: '₹6,499', image: '/product_bomber.jpg' },
  { id: 4, name: 'Signal Cargo', price: '₹3,999', image: '/product_cargo.jpg' },
  { id: 5, name: 'Tag Cap', price: '₹1,799', image: '/product_cap.jpg' },
  { id: 6, name: 'Stencil Socks (2-pack)', price: '₹999', image: '/product_socks.jpg' },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [cartCount] = useState(0);
  
  // Section refs
  const heroRef = useRef<HTMLDivElement>(null);
  const lookbookRef = useRef<HTMLDivElement>(null);
  const streetRef = useRef<HTMLDivElement>(null);
  const collectionRef = useRef<HTMLDivElement>(null);
  const shopRef = useRef<HTMLDivElement>(null);
  const manifestoRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);
  
  // Element refs for animations
  const heroLogoRef = useRef<HTMLDivElement>(null);
  const heroImageRef = useRef<HTMLDivElement>(null);
  const heroLabelRef = useRef<HTMLDivElement>(null);
  const heroCtaRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero entrance animation (on load)
      const heroTl = gsap.timeline({ delay: 0.3 });
      
      heroTl
        .fromTo(heroImageRef.current, 
          { opacity: 0, scale: 1.06 }, 
          { opacity: 1, scale: 1, duration: 1.1, ease: 'power2.out' }
        )
        .fromTo(heroLogoRef.current, 
          { opacity: 0, scale: 0.92 }, 
          { opacity: 1, scale: 1, duration: 0.9, ease: 'power3.out' }, 
          '-=0.8'
        )
        .fromTo(navRef.current?.children ? Array.from(navRef.current.children) : [], 
          { y: -20, opacity: 0 }, 
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.08, ease: 'power2.out' }, 
          '-=0.5'
        )
        .fromTo(heroLabelRef.current, 
          { x: -30, opacity: 0 }, 
          { x: 0, opacity: 1, duration: 0.6, ease: 'power2.out' }, 
          '-=0.4'
        )
        .fromTo(heroCtaRef.current, 
          { y: 20, opacity: 0 }, 
          { y: 0, opacity: 1, duration: 0.6, ease: 'power2.out' }, 
          '-=0.4'
        );

      // Hero scroll animation (exit only)
      const heroScrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
          onLeaveBack: () => {
            // Reset hero elements when scrolling back to top
            gsap.set([heroLogoRef.current, heroImageRef.current, heroLabelRef.current, heroCtaRef.current], {
              opacity: 1, x: 0, y: 0, scale: 1
            });
          }
        }
      });

      heroScrollTl
        .fromTo(heroLogoRef.current, 
          { opacity: 1 }, 
          { opacity: 0, ease: 'power2.in' }, 
          0.7
        )
        .fromTo(heroImageRef.current, 
          { x: 0, scale: 1, opacity: 1 }, 
          { x: '-18vw', scale: 1.08, opacity: 0, ease: 'power2.in' }, 
          0.7
        )
        .fromTo([heroLabelRef.current, heroCtaRef.current], 
          { y: 0, opacity: 1 }, 
          { y: '12vh', opacity: 0, ease: 'power2.in' }, 
          0.7
        );

      // Lookbook Section
      const lookbookLeft = lookbookRef.current?.querySelector('.lookbook-left');
      const lookbookRightTop = lookbookRef.current?.querySelector('.lookbook-right-top');
      const lookbookRightBottom = lookbookRef.current?.querySelector('.lookbook-right-bottom');
      const lookbookDivider = lookbookRef.current?.querySelector('.lookbook-divider');
      const lookbookText = lookbookRef.current?.querySelector('.lookbook-text');

      if (lookbookLeft && lookbookRightTop && lookbookRightBottom && lookbookDivider && lookbookText) {
        const lookbookScrollTl = gsap.timeline({
          scrollTrigger: {
            trigger: lookbookRef.current,
            start: 'top top',
            end: '+=130%',
            pin: true,
            scrub: 0.5,
          }
        });

        lookbookScrollTl
          .fromTo(lookbookLeft, 
            { x: '-60vw', opacity: 0 }, 
            { x: 0, opacity: 1, ease: 'none' }, 
            0
          )
          .fromTo(lookbookRightTop, 
            { x: '60vw', opacity: 0 }, 
            { x: 0, opacity: 1, ease: 'none' }, 
            0
          )
          .fromTo(lookbookRightBottom, 
            { x: '60vw', opacity: 0 }, 
            { x: 0, opacity: 1, ease: 'none' }, 
            0.06
          )
          .fromTo(lookbookDivider, 
            { scaleY: 0 }, 
            { scaleY: 1, ease: 'none' }, 
            0.1
          )
          .fromTo(lookbookText, 
            { y: '40vh', opacity: 0 }, 
            { y: 0, opacity: 1, ease: 'none' }, 
            0.12
          )
          .to(lookbookLeft, 
            { x: '-35vw', opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to([lookbookRightTop, lookbookRightBottom], 
            { x: '35vw', opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to(lookbookText, 
            { y: '18vh', opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to(lookbookDivider, 
            { scaleY: 0, ease: 'power2.in' }, 
            0.85
          );
      }

      // Street Statement Section
      const streetBg = streetRef.current?.querySelector('.street-bg');
      const streetLabel = streetRef.current?.querySelector('.street-label');
      const streetHeading = streetRef.current?.querySelector('.street-heading');
      const streetRule = streetRef.current?.querySelector('.street-rule');
      const streetCta = streetRef.current?.querySelector('.street-cta');

      if (streetBg && streetLabel && streetHeading && streetRule && streetCta) {
        const streetScrollTl = gsap.timeline({
          scrollTrigger: {
            trigger: streetRef.current,
            start: 'top top',
            end: '+=130%',
            pin: true,
            scrub: 0.5,
          }
        });

        streetScrollTl
          .fromTo(streetBg, 
            { scale: 1.14, opacity: 0 }, 
            { scale: 1, opacity: 1, ease: 'none' }, 
            0
          )
          .fromTo(streetLabel, 
            { x: '20vw', opacity: 0 }, 
            { x: 0, opacity: 1, ease: 'none' }, 
            0.08
          )
          .fromTo(streetHeading, 
            { y: '60vh', opacity: 0 }, 
            { y: 0, opacity: 1, ease: 'none' }, 
            0.1
          )
          .fromTo(streetRule, 
            { scaleX: 0 }, 
            { scaleX: 1, ease: 'none' }, 
            0.18
          )
          .fromTo(streetCta, 
            { y: '10vh', opacity: 0 }, 
            { y: 0, opacity: 1, ease: 'none' }, 
            0.2
          )
          .to(streetHeading, 
            { y: '-30vh', opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to(streetBg, 
            { x: '18vw', opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to([streetLabel, streetCta], 
            { opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to(streetRule, 
            { scaleX: 0, ease: 'power2.in' }, 
            0.85
          );
      }

      // Collection Section
      const collLeft = collectionRef.current?.querySelector('.collection-left');
      const collRight = collectionRef.current?.querySelector('.collection-right');
      const collLabel = collectionRef.current?.querySelector('.collection-label');
      const collHeading = collectionRef.current?.querySelector('.collection-heading');
      const collCta = collectionRef.current?.querySelector('.collection-cta');

      if (collLeft && collRight && collLabel && collHeading && collCta) {
        const collectionScrollTl = gsap.timeline({
          scrollTrigger: {
            trigger: collectionRef.current,
            start: 'top top',
            end: '+=130%',
            pin: true,
            scrub: 0.5,
          }
        });

        collectionScrollTl
          .fromTo(collLeft, 
            { x: '-60vw', opacity: 0 }, 
            { x: 0, opacity: 1, ease: 'none' }, 
            0
          )
          .fromTo(collRight, 
            { x: '60vw', opacity: 0 }, 
            { x: 0, opacity: 1, ease: 'none' }, 
            0
          )
          .fromTo(collLabel, 
            { y: '-10vh', opacity: 0 }, 
            { y: 0, opacity: 1, ease: 'none' }, 
            0.1
          )
          .fromTo(collHeading, 
            { scale: 0.72, y: '10vh', opacity: 0 }, 
            { scale: 1, y: 0, opacity: 1, ease: 'none' }, 
            0.12
          )
          .fromTo(collCta, 
            { y: '18vh', opacity: 0 }, 
            { y: 0, opacity: 1, ease: 'none' }, 
            0.18
          )
          .to(collHeading, 
            { scale: 1.25, opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to([collLeft, collRight], 
            { opacity: 0, ease: 'power2.in' }, 
            0.7
          )
          .to(collCta, 
            { y: '12vh', opacity: 0, ease: 'power2.in' }, 
            0.7
          );
      }

      // Shop Section (flowing)
      const shopHeading = shopRef.current?.querySelector('.shop-heading');
      const shopCards = shopRef.current?.querySelectorAll('.product-card');

      if (shopHeading) {
        gsap.fromTo(shopHeading, 
          { y: '6vh', opacity: 0 }, 
          { 
            y: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: shopHeading,
              start: 'top 80%',
              end: 'top 55%',
              scrub: 0.3,
            }
          }
        );
      }

      shopCards?.forEach((card) => {
        gsap.fromTo(card, 
          { y: '10vh', rotate: -1, opacity: 0 }, 
          { 
            y: 0, 
            rotate: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              end: 'top 60%',
              scrub: 0.3,
            }
          }
        );
      });

      // Manifesto Section (flowing)
      const manifestoHeading = manifestoRef.current?.querySelector('.manifesto-heading');
      const manifestoCard = manifestoRef.current?.querySelector('.manifesto-card');

      if (manifestoHeading) {
        gsap.fromTo(manifestoHeading, 
          { x: '-8vw', opacity: 0 }, 
          { 
            x: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: manifestoHeading,
              start: 'top 80%',
              end: 'top 55%',
              scrub: 0.3,
            }
          }
        );
      }

      if (manifestoCard) {
        gsap.fromTo(manifestoCard, 
          { x: '8vw', opacity: 0 }, 
          { 
            x: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: manifestoCard,
              start: 'top 75%',
              end: 'top 50%',
              scrub: 0.3,
            }
          }
        );
      }

      // Contact Section (flowing)
      const contactLeft = contactRef.current?.querySelector('.contact-left');
      const contactRight = contactRef.current?.querySelector('.contact-right');

      if (contactLeft) {
        gsap.fromTo(contactLeft, 
          { y: '6vh', opacity: 0 }, 
          { 
            y: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: contactLeft,
              start: 'top 80%',
              end: 'top 60%',
              scrub: 0.3,
            }
          }
        );
      }

      if (contactRight) {
        gsap.fromTo(contactRight, 
          { y: '8vh', opacity: 0 }, 
          { 
            y: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: contactRight,
              start: 'top 80%',
              end: 'top 55%',
              scrub: 0.3,
            }
          }
        );
      }

      // Global snap for pinned sections
      setTimeout(() => {
        const pinned = ScrollTrigger.getAll()
          .filter(st => st.vars.pin)
          .sort((a, b) => a.start - b.start);
        
        const maxScroll = ScrollTrigger.maxScroll(window);
        
        if (maxScroll && pinned.length > 0) {
          const pinnedRanges = pinned.map(st => ({
            start: st.start / maxScroll,
            end: (st.end ?? st.start) / maxScroll,
            center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
          }));

          ScrollTrigger.create({
            snap: {
              snapTo: (value: number) => {
                const inPinned = pinnedRanges.some(r => 
                  value >= r.start - 0.02 && value <= r.end + 0.02
                );
                if (!inPinned) return value;

                const target = pinnedRanges.reduce((closest, r) =>
                  Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
                  pinnedRanges[0]?.center ?? 0
                );
                return target;
              },
              duration: { min: 0.15, max: 0.35 },
              delay: 0,
              ease: 'power2.out',
            }
          });
        }
      }, 100);
    });

    return () => ctx.revert();
  }, []);

  const scrollToSection = (ref: React.RefObject<HTMLDivElement | null>) => {
    setMenuOpen(false);
    ref.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative bg-brand-black min-h-screen">
      {/* Grain Overlay */}
      <div className="grain-overlay" />

      {/* Navigation */}
      <nav ref={navRef} className="fixed top-0 left-0 w-full z-50 px-[4vw] py-6 flex justify-between items-center">
        <div className="font-display text-xl text-brand-white tracking-tight">
          boldlook
        </div>
        <div className="flex items-center gap-4">
          <button className="relative p-2 text-brand-white hover:text-brand-lime transition-colors">
            <ShoppingBag size={22} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-brand-lime text-brand-black text-xs font-bold rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
          <button 
            onClick={() => setMenuOpen(true)}
            className="px-6 py-2 bg-brand-white/10 backdrop-blur-sm rounded-full text-brand-white font-mono text-sm hover:bg-brand-lime hover:text-brand-black transition-all duration-300"
          >
            MENU
          </button>
        </div>
      </nav>

      {/* Menu Overlay */}
      {menuOpen && (
        <div className="menu-overlay animate-in fade-in duration-300">
          <button 
            onClick={() => setMenuOpen(false)}
            className="absolute top-6 right-[4vw] p-2 text-brand-white hover:text-brand-lime transition-colors"
          >
            <X size={28} />
          </button>
          <div className="menu-item" onClick={() => scrollToSection(lookbookRef)}>LOOKBOOK</div>
          <div className="menu-item" onClick={() => scrollToSection(collectionRef)}>COLLECTION 01</div>
          <div className="menu-item" onClick={() => scrollToSection(shopRef)}>SHOP</div>
          <div className="menu-item" onClick={() => scrollToSection(manifestoRef)}>MANIFESTO</div>
          <div className="menu-item" onClick={() => scrollToSection(contactRef)}>CONTACT</div>
        </div>
      )}

      {/* Section 1: Hero */}
      <section ref={heroRef} className="section-pinned z-10">
        <div 
          ref={heroImageRef}
          className="absolute inset-0 w-full h-full"
        >
          <img 
            src="/hero_portrait.jpg" 
            alt="Hero" 
            className="w-full h-full object-cover img-mono"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-black/60 via-transparent to-brand-black/30" />
        </div>
        
        <div 
          ref={heroLogoRef}
          className="absolute left-1/2 top-[52%] -translate-x-1/2 -translate-y-1/2 z-10"
        >
          <h1 className="font-display text-outline text-[clamp(48px,12vw,160px)] whitespace-nowrap">
            BOLDLOOK
          </h1>
        </div>

        <div 
          ref={heroLabelRef}
          className="absolute left-[4vw] bottom-[4vh] z-10"
        >
          <p className="font-mono text-xs text-brand-gray tracking-widest">
            BOLDLOOK BY YOGI_NATION
          </p>
        </div>

        <div 
          ref={heroCtaRef}
          className="absolute right-[4vw] bottom-[4vh] z-10 flex flex-col items-end gap-2"
        >
          <p className="font-mono text-xs text-brand-lime tracking-widest">
            NEW SEASON LIVE
          </p>
          <button className="btn-primary flex items-center gap-2">
            ENTER THE DROP
            <ArrowRight size={18} />
          </button>
        </div>
      </section>

      {/* Section 2: Lookbook */}
      <section ref={lookbookRef} className="section-pinned z-20 bg-brand-black">
        <div className="lookbook-left absolute left-0 top-0 w-1/2 h-full">
          <img 
            src="/lookbook_left.jpg" 
            alt="Lookbook" 
            className="w-full h-full object-cover img-mono"
          />
        </div>
        <div className="lookbook-right-top absolute right-0 top-0 w-1/2 h-1/2">
          <img 
            src="/lookbook_right_top.jpg" 
            alt="Lookbook" 
            className="w-full h-full object-cover img-mono"
          />
        </div>
        <div className="lookbook-right-bottom absolute right-0 bottom-0 w-1/2 h-1/2">
          <img 
            src="/lookbook_right_bottom.jpg" 
            alt="Lookbook" 
            className="w-full h-full object-cover img-mono"
          />
        </div>
        
        <div className="lookbook-divider absolute left-1/2 top-[10vh] w-px h-[80vh] bg-brand-lime/40 origin-top" />
        
        <div className="lookbook-text absolute left-[4vw] bottom-[6vh] z-10">
          <h2 className="font-display text-[clamp(36px,5vw,72px)] text-brand-white mb-2">
            LOOKBOOK
          </h2>
          <div className="accent-line w-24 mb-4" />
          <p className="text-brand-gray max-w-[34vw] text-sm leading-relaxed mb-4">
            Night portraits, raw textures, and pieces built for the street.
          </p>
          <button className="font-mono text-xs text-brand-lime tracking-widest hover:underline">
            VIEW LOOKBOOK
          </button>
        </div>
      </section>

      {/* Section 3: Street Statement */}
      <section ref={streetRef} className="section-pinned z-30 bg-brand-black">
        <div className="street-bg absolute inset-0 w-full h-full">
          <img 
            src="/street_scene.jpg" 
            alt="Street" 
            className="w-full h-full object-cover img-mono"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-black/70 via-transparent to-brand-black/50" />
        </div>
        
        <div className="street-label absolute right-[4vw] top-[6vh] z-10">
          <p className="font-mono text-xs text-brand-gray tracking-widest">
            BOLDLOOK BY YOGI_NATION
          </p>
        </div>

        <div className="absolute left-[4vw] bottom-[10vh] z-10">
          <h2 className="street-heading font-display text-[clamp(32px,6vw,96px)] text-brand-white leading-tight max-w-[92vw]">
            STREET IS THE NEW LUXURY
          </h2>
          <div className="street-rule accent-line w-[60vw] mt-4 origin-left" />
          <button className="street-cta mt-6 font-mono text-xs text-brand-lime tracking-widest hover:underline flex items-center gap-2">
            READ THE MANIFESTO
            <ArrowRight size={14} />
          </button>
        </div>
      </section>

      {/* Section 4: Collection 01 */}
      <section ref={collectionRef} className="section-pinned z-40 bg-brand-black">
        <div className="collection-left absolute left-0 top-0 w-1/2 h-full">
          <img 
            src="/collection_left.jpg" 
            alt="Collection" 
            className="w-full h-full object-cover img-mono"
          />
        </div>
        <div className="collection-right absolute right-0 top-0 w-1/2 h-full">
          <img 
            src="/collection_right.jpg" 
            alt="Collection" 
            className="w-full h-full object-cover img-mono"
          />
        </div>
        
        <div className="collection-label absolute left-[4vw] top-[6vh] z-10">
          <p className="font-mono text-xs text-brand-gray tracking-widest">
            BOLDLOOK BY YOGI_NATION
          </p>
        </div>

        <div className="collection-heading absolute left-1/2 top-[52%] -translate-x-1/2 -translate-y-1/2 z-10 text-center">
          <h2 
            className="font-display text-[clamp(48px,10vw,140px)] text-brand-white"
            style={{ textShadow: '0 10px 30px rgba(0,0,0,0.8)' }}
          >
            COLLECTION 01
          </h2>
        </div>

        <div className="collection-cta absolute left-1/2 bottom-[6vh] -translate-x-1/2 z-10 flex flex-col items-center gap-2">
          <p className="font-mono text-xs text-brand-gray tracking-widest">
            LIMITED UNITS
          </p>
          <button className="btn-primary">
            SHOP THE DROP
          </button>
        </div>
      </section>

      {/* Section 5: Shop Grid */}
      <section ref={shopRef} className="relative z-50 bg-brand-black py-20 px-[4vw]">
        <div className="shop-heading flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h2 className="font-display text-[clamp(36px,5vw,64px)] text-brand-white mb-2">
              NEW DROP
            </h2>
            <p className="text-brand-gray text-sm">
              Built for movement. Designed to stand out.
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            {['ALL', 'HOODIES', 'TEES', 'OUTERWEAR'].map((filter) => (
              <button 
                key={filter}
                className="px-4 py-2 rounded-full border border-brand-white/20 text-brand-white text-xs font-mono hover:border-brand-lime hover:text-brand-lime transition-colors"
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div key={product.id} className="product-card group">
              <div className="aspect-square overflow-hidden bg-[#141416]">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="product-image w-full h-full object-cover transition-transform duration-500"
                />
              </div>
              <div className="p-4">
                <h3 className="text-brand-white font-medium mb-1">{product.name}</h3>
                <p className="text-brand-lime font-mono text-sm mb-3">{product.price}</p>
                <button className="w-full py-3 bg-brand-white/5 text-brand-white text-sm font-medium rounded-lg hover:bg-brand-lime hover:text-brand-black transition-all duration-300">
                  ADD TO CART
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="btn-outline">
            VIEW ALL PRODUCTS
          </button>
        </div>
      </section>

      {/* Section 6: Manifesto */}
      <section ref={manifestoRef} className="relative z-50 bg-brand-crimson py-20 px-[4vw]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="manifesto-heading">
            <h2 className="font-display text-[clamp(42px,6vw,80px)] text-brand-white leading-tight mb-6">
              THIS IS NOT BASIC.
            </h2>
            <p className="text-brand-white/80 text-lg leading-relaxed max-w-md">
              We design for the ones who move different. Join the list—first access to drops, no spam.
            </p>
          </div>

          <div className="manifesto-card bg-brand-black p-8 rounded-xl">
            <p className="font-mono text-xs text-brand-lime tracking-widest mb-4">
              JOIN THE LIST
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <input 
                type="email"
                placeholder="Email address"
                className="flex-1 px-4 py-3 bg-brand-white/5 border border-brand-white/10 rounded-lg text-brand-white placeholder:text-brand-gray focus:outline-none focus:border-brand-lime transition-colors"
              />
              <button className="btn-primary whitespace-nowrap">
                SUBSCRIBE
              </button>
            </div>
            <p className="mt-4 text-brand-gray text-xs">
              Unsubscribe anytime. We don't share your data.
            </p>
          </div>
        </div>
      </section>

      {/* Section 7: Contact */}
      <section ref={contactRef} className="relative z-50 bg-brand-black py-20 px-[4vw]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="contact-left">
            <h2 className="font-display text-[clamp(36px,5vw,64px)] text-brand-white mb-6">
              COLLABORATE
            </h2>
            <p className="text-brand-gray text-lg leading-relaxed mb-8">
              Stockists, press, and creative collabs—reach out.
            </p>
            <div className="space-y-4">
              <a 
                href="mailto:hello@boldlook.co" 
                className="block text-brand-white hover:text-brand-lime transition-colors"
              >
                hello@boldlook.co
              </a>
              <p className="text-brand-gray">
                Delhi + Mumbai
              </p>
            </div>
          </div>

          <div className="contact-right">
            <form className="space-y-6">
              <div>
                <label className="block font-mono text-xs text-brand-gray tracking-widest mb-2">
                  NAME
                </label>
                <input 
                  type="text"
                  className="w-full px-4 py-3 bg-brand-white/5 border border-brand-white/10 rounded-lg text-brand-white focus:outline-none focus:border-brand-lime transition-colors"
                />
              </div>
              <div>
                <label className="block font-mono text-xs text-brand-gray tracking-widest mb-2">
                  EMAIL
                </label>
                <input 
                  type="email"
                  className="w-full px-4 py-3 bg-brand-white/5 border border-brand-white/10 rounded-lg text-brand-white focus:outline-none focus:border-brand-lime transition-colors"
                />
              </div>
              <div>
                <label className="block font-mono text-xs text-brand-gray tracking-widest mb-2">
                  MESSAGE
                </label>
                <textarea 
                  rows={4}
                  className="w-full px-4 py-3 bg-brand-white/5 border border-brand-white/10 rounded-lg text-brand-white focus:outline-none focus:border-brand-lime transition-colors resize-none"
                />
              </div>
              <button type="submit" className="btn-primary w-full">
                SEND MESSAGE
              </button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-brand-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-brand-gray text-sm">
            © 2026 boldlook by yogi_nation. All rights reserved.
          </p>
          <div className="flex gap-6">
            {['Instagram', 'TikTok', 'Twitter'].map((social) => (
              <a 
                key={social}
                href="#"
                className="text-brand-gray hover:text-brand-lime transition-colors text-sm"
              >
                {social}
              </a>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;

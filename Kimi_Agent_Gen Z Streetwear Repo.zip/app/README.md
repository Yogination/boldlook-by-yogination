# boldlook by yogi_nation 🚀

[![Website](https://img.shields.io/badge/Live%20Site-boldlook.vercel.app-neonlime?style=for-the-badge)](https://2wsjpshmj3szy.ok.kimi.link)
[![React](https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178C6?style=for-the-badge&logo=typescript)](https://www.typescriptlang.org/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4-06B6D4?style=for-the-badge&logo=tailwindcss)](https://tailwindcss.com/)
[![GSAP](https://img.shields.io/badge/GSAP-3.0-88CE02?style=for-the-badge)](https://greensock.com/gsap/)

> **"Street Is The New Luxury."**

A viral-ready Gen Z streetwear brand website featuring edgy night editorial aesthetics, cinematic scroll animations, and a premium underground vibe.

![boldlook Preview](./public/hero_portrait.jpg)

---

## ✨ Features

### 🎨 Design System
- **Color Palette**: Near-black (#0B0B0D) dominant, neon lime (#B6FF2E) accents, deep crimson (#6B2B2B) highlights
- **Typography**: Archivo Black (display), Inter (body), Space Mono (labels)
- **Visual Treatment**: High-contrast monochrome + cool blue tint photography
- **Texture**: Static grain overlay for gritty street aesthetic

### 🎬 Sections (7 Total)

| Section | Type | Description |
|---------|------|-------------|
| **Hero** | Pinned | Full-bleed night portrait with giant outline "BOLDLOOK" logo |
| **Lookbook** | Pinned | Split editorial layout with 3-panel image grid |
| **Street Statement** | Pinned | "STREET IS THE NEW LUXURY" manifesto headline |
| **Collection 01** | Pinned | Two-panel portraits with centered collection title |
| **Shop Grid** | Flowing | 6-product e-commerce grid with filter chips |
| **Manifesto** | Flowing | Crimson background with newsletter signup |
| **Contact** | Flowing | Collaboration form + footer |

### 🎥 Animations (GSAP + ScrollTrigger)
- **Pinned sections** with three-phase transitions (entrance → settle → exit)
- **Global scroll snap** for smooth section landing
- **Z-index stacking** for overlay-style scene transitions
- **Parallax effects** on images and text elements
- **Cinematic scrub** animations tied to scroll progress

---

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/boldlook.git
cd boldlook

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Environment Variables
Create a `.env` file in the root directory:

```env
VITE_APP_TITLE=boldlook by yogi_nation
```

---

## 📁 Project Structure

```
boldlook/
├── public/                 # Static assets
│   ├── hero_portrait.jpg
│   ├── lookbook_*.jpg
│   ├── collection_*.jpg
│   ├── street_scene.jpg
│   ├── product_*.jpg
│   └── logo.png
├── src/
│   ├── App.tsx            # Main application component
│   ├── App.css            # App-specific styles
│   ├── index.css          # Global styles + Tailwind
│   └── main.tsx           # Entry point
├── index.html
├── tailwind.config.js     # Tailwind configuration
├── vite.config.ts         # Vite configuration
├── tsconfig.json          # TypeScript configuration
└── package.json
```

---

## 🛠 Tech Stack

| Technology | Purpose |
|------------|---------|
| **React 18** | UI Framework |
| **TypeScript** | Type Safety |
| **Vite** | Build Tool |
| **Tailwind CSS** | Styling |
| **GSAP** | Animations |
| **ScrollTrigger** | Scroll-based animations |
| **Lucide React** | Icons |

---

## 🎨 Brand Identity

### Logo
![boldlook Logo](./public/logo.png)

Minimal typographic logo with neon lime lightning bolt through the "B" - designed for instant recognition across digital and print.

### Color Palette

```css
--brand-black: #0B0B0D;      /* Primary background */
--brand-crimson: #6B2B2B;    /* Accent background */
--brand-lime: #B6FF2E;       /* CTAs, highlights */
--brand-white: #F4F4F5;      /* Primary text */
--brand-gray: #A1A1AA;       /* Secondary text */
```

### Typography

| Usage | Font | Weight |
|-------|------|--------|
| Headlines | Archivo Black | 400 |
| Body | Inter | 400-500 |
| Labels | Space Mono | 400 |

---

## 📱 Responsive Breakpoints

| Breakpoint | Width | Adjustments |
|------------|-------|-------------|
| Mobile | < 640px | Stacked layouts, reduced type sizes |
| Tablet | 640-1024px | 2-column grids |
| Desktop | > 1024px | Full experience |

---

## 🎯 Key Components

### Navigation
```tsx
<nav className="fixed top-0 w-full z-50">
  <div className="font-display text-xl">boldlook</div>
  <button className="bg-white/10 backdrop-blur-sm rounded-full">
    MENU
  </button>
</nav>
```

### Product Card
```tsx
<div className="product-card group">
  <img className="product-image" src={image} />
  <h3>{name}</h3>
  <p className="text-brand-lime">{price}</p>
  <button>ADD TO CART</button>
</div>
```

### Pinned Section Pattern
```tsx
<section ref={sectionRef} className="section-pinned">
  {/* GSAP ScrollTrigger handles pinning */}
</section>
```

---

## 🎬 Animation System

### ScrollTrigger Configuration
```typescript
const scrollTl = gsap.timeline({
  scrollTrigger: {
    trigger: sectionRef.current,
    start: 'top top',
    end: '+=130%',
    pin: true,
    scrub: 0.5,
  }
});
```

### Three-Phase Animation
1. **Entrance (0-30%)**: Elements enter from off-screen
2. **Settle (30-70%)**: Static viewing state
3. **Exit (70-100%)**: Elements exit, next section overlays

### Global Snap
```typescript
ScrollTrigger.create({
  snap: {
    snapTo: (value) => {
      // Snap only within pinned ranges
    },
    duration: { min: 0.15, max: 0.35 },
    ease: 'power2.out',
  }
});
```

---

## 🛒 Product Catalog

| Product | Price | Category |
|---------|-------|----------|
| Night Hoodie | ₹4,999 | Hoodies |
| Concrete Tee | ₹2,499 | Tees |
| Metro Bomber | ₹6,499 | Outerwear |
| Signal Cargo | ₹3,999 | Bottoms |
| Tag Cap | ₹1,799 | Accessories |
| Stencil Socks | ₹999 | Accessories |

---

## 📸 Image Treatment

All photography uses consistent treatment:
```css
filter: grayscale(90%) contrast(1.15) brightness(0.95);
```

Plus global grain overlay for texture.

---

## 🔗 Links

- **Live Site**: https://2wsjpshmj3szy.ok.kimi.link
- **Design Doc**: See `Design.md` for full specifications

---

## 📄 License

MIT License - feel free to use this as a template for your own streetwear brand!

---

## 🙏 Credits

- **Design & Development**: Created with ❤️ for the streetwear community
- **Fonts**: Google Fonts (Archivo Black, Inter, Space Mono)
- **Icons**: Lucide React
- **Animations**: GSAP + ScrollTrigger

---

> **"This Is Not Basic."** - boldlook by yogi_nation
